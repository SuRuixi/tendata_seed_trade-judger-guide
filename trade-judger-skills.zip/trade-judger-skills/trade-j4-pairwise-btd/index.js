#!/usr/bin/env node
'use strict';

const { clamp, requireArray, requireObject, requireString, round, runCli } = require('../shared/lib');

function evaluate(input) {
  requireObject(input);
  const models = requireArray(input.models, 'models');
  const comparisons = requireArray(input.comparisons, 'comparisons');
  if (models.length < 2 || new Set(models).size !== models.length) throw new Error('models 至少含两个唯一模型');
  if (!comparisons.length) throw new Error('comparisons 不得为空');

  const index = new Map(models.map((model, i) => [model, i]));
  const counts = Array(models.length).fill(0);
  const rows = comparisons.map((row, i) => {
    requireObject(row, `comparisons[${i}]`);
    requireString(row.task_id, `comparisons[${i}].task_id`);
    requireString(row.reason, `comparisons[${i}].reason`);
    if (!index.has(row.a) || !index.has(row.b) || row.a === row.b) throw new Error(`非法 pair：${row.a}/${row.b}`);
    if (!['A', 'B', 'Same'].includes(row.outcome)) throw new Error(`非法 outcome：${row.outcome}`);
    if (!Number.isFinite(row.confidence) || row.confidence < 0 || row.confidence > 1) throw new Error('confidence 必须在 0..1');
    requireArray(row.evidence_refs, 'evidence_refs');
    requireArray(row.decisive_dimensions, 'decisive_dimensions');
    if (row.outcome !== 'Same' && !row.evidence_refs.length) throw new Error('非 Same 比较必须含 evidence_refs');
    counts[index.get(row.a)]++;
    counts[index.get(row.b)]++;
    return {
      i: index.get(row.a), j: index.get(row.b), outcome: row.outcome,
      weight: (row.weight == null ? 1 : Number(row.weight)) * Math.max(0.05, row.confidence)
    };
  });

  const n = models.length;
  const beta = Array(n).fill(0);
  let eta = 0;
  const m = Array(n + 1).fill(0);
  const v = Array(n + 1).fill(0);
  const iterations = input.iterations || 2500;
  const lr = input.learning_rate || 0.03;

  for (let step = 1; step <= iterations; step++) {
    const gradient = Array(n + 1).fill(0);
    const nu = Math.exp(eta);
    for (const row of rows) {
      const pi = Math.exp(beta[row.i]);
      const pj = Math.exp(beta[row.j]);
      const tie = nu * Math.sqrt(pi * pj);
      const den = pi + pj + tie;
      const piP = pi / den;
      const pjP = pj / den;
      const tieP = tie / den;
      const yi = row.outcome === 'A' ? 1 : row.outcome === 'Same' ? 0.5 : 0;
      const yj = row.outcome === 'B' ? 1 : row.outcome === 'Same' ? 0.5 : 0;
      const yt = row.outcome === 'Same' ? 1 : 0;
      gradient[row.i] += row.weight * (yi - piP - 0.5 * tieP + 0.5 * yt);
      gradient[row.j] += row.weight * (yj - pjP - 0.5 * tieP + 0.5 * yt);
      gradient[n] += row.weight * (yt - tieP);
    }
    for (let k = 0; k <= n; k++) {
      gradient[k] -= 0.001 * (k === n ? eta : beta[k]);
      m[k] = 0.9 * m[k] + 0.1 * gradient[k];
      v[k] = 0.999 * v[k] + 0.001 * gradient[k] ** 2;
      const delta = lr * (m[k] / (1 - 0.9 ** step)) / (Math.sqrt(v[k] / (1 - 0.999 ** step)) + 1e-8);
      if (k === n) eta = clamp(eta + delta, -4, 4);
      else beta[k] = clamp(beta[k] + delta, -8, 8);
    }
    const mean = beta.reduce((a, b) => a + b, 0) / n;
    for (let k = 0; k < n; k++) beta[k] -= mean;
  }

  const strengths = beta.map(Math.exp);
  const min = Math.min(...strengths);
  const max = Math.max(...strengths);
  const scores = strengths.map(value => max === min ? 50 : 100 * (value - min) / (max - min));
  const order = models.map((model, i) => ({ model_id: model, i })).sort((a, b) => scores[b.i] - scores[a.i]);
  const threshold = input.group_threshold ?? 8;
  let group = 1;
  const groups = [[]];
  const rankings = order.map((row, rank) => {
    if (rank > 0 && scores[order[rank - 1].i] - scores[row.i] > threshold &&
        counts[order[rank - 1].i] >= 2 && counts[row.i] >= 2) {
      group++;
      groups.push([]);
    }
    groups[group - 1].push(row.model_id);
    return {
      model_id: row.model_id, rank: rank + 1, rank_group: group,
      strength: round(strengths[row.i]), score: round(scores[row.i], 2), comparisons: counts[row.i]
    };
  });

  const nu = Math.exp(eta);
  let logLikelihood = 0;
  for (const row of rows) {
    const pi = strengths[row.i], pj = strengths[row.j], tie = nu * Math.sqrt(pi * pj);
    const den = pi + pj + tie;
    const p = row.outcome === 'A' ? pi / den : row.outcome === 'B' ? pj / den : tie / den;
    logLikelihood += row.weight * Math.log(Math.max(p, 1e-15));
  }
  return {
    method: 'Bradley-Terry-Davidson MLE',
    tie_parameter: round(nu), log_likelihood: round(logLikelihood),
    comparison_count: comparisons.length, rankings, rank_groups: groups
  };
}

if (require.main === module) runCli(evaluate, 'ranking.json');
module.exports = { evaluate };
