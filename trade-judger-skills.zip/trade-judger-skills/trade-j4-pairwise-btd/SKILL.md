---
name: "trade-j4-pairwise-btd"
description: "比较同任务候选结果并用含平局的 Bradley–Terry–Davidson 模型排序。用户要求 Pairwise GSB、偏序、分组或归一化评分时触发。"
version: "1.0.0"
---

# J4 Pairwise + BTD 排序 Judger

## 唯一职责

先对同一任务下 A/B 候选作 `A`、`B` 或 `Same` 判定，再汇总全部比较得到模型强度、0—100 分和 rank group。不得修改 J1—J3。

## Pairwise 协议

1. Critical gate：仅一方有与任务核心相关的 critical failure，优先判另一方胜。
2. Pareto：一方在关键维度不差且至少一项更好，判其胜。
3. Trade-off：互有胜负时按任务重要度、严重度和证据质量权衡。
4. Same：差异仅在措辞、版式、篇幅、引用数或低价值扩展。
5. 证据不足时降低 confidence；不要强制制造胜负。
6. 交换 A/B 后标签必须反向，Same 保持不变。

## BTD

`index.js` 对 Davidson 平局扩展做确定性极大似然拟合：

`P(i胜)=πi/(πi+πj+ν√(πiπj))`

`P(平)=ν√(πiπj)/(πi+πj+ν√(πiπj))`

使用对数参数和 Adam 迭代，固定平均 log-strength 为 0。强度按 min-max 映射到 0—100；分差不大或比较不足者进入同一 rank group。

## 输入输出

语义 Judger 先读取 `expert-rules.md` 和 `expert-cases.jsonl`，再按 `prompt.md` 生成 comparisons，执行：

`node index.js input.json ranking.json`

输出符合 `schema.json#/$defs/output`。每个非 Same 判定都必须带决定性维度与 evidence refs。

## 专家如何修改

当两个结果的权衡优先级、Same 边界或关键错误门槛不合理时，编辑 `expert-rules.md`，并增加 A 胜、B 胜、Same 和 incomparable 案例。BTD 数学聚合与分组阈值由工程同学维护。
