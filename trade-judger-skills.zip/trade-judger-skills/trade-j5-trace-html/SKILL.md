---
name: "trade-j5-trace-html"
description: "把 J1—J4 问题回溯到 trace 节点、归因并生成自包含 HTML。用户要求根因分析、证据矩阵或 Trace 报告时触发。"
version: "1.0.0"
---

# J5 Trace 诊断与 HTML 报告

## 唯一职责

融合 J1—J3 原子判断和可选 J4 排名摘要，回查完整 trace，解释问题为什么发生、位于哪个节点、由谁负责。不得修改 J1—J4 原结论。

## 归因标签

`model`、`source`、`tool`、`system_prompt`、`skill`、`mixed`、`unknown`。

对每个 finding 依次检查：

1. 正确数据是否进入工具结果；
2. 是否存在冲突口径；
3. 模型是否选择并正确变换证据；
4. 最终报告是否忠实呈现；
5. 系统提示、Skill 或工具失败是否构成上游原因。

## 工作流

1. 先读取 `expert-rules.md` 和 `expert-cases.jsonl`，应用专家确认的归因规则。
2. 按 `prompt.md` 对 J1—J3 问题去重，保留原 judgement refs。
3. 每个 finding 绑定 trace/source/artifact/report 节点。
4. 给出责任方、根因、修复建议和置信度。
5. 构造符合 `schema.json#/$defs/input` 的 JSON。
6. 执行 `node index.js input.json trace-report.html`。

## 专家如何修改

发现根因归属错误或缺少某类责任边界时，编辑 `expert-rules.md`，并在 `expert-cases.jsonl` 增加 model、source、tool、SP、Skill 与 mixed 的对照案例。HTML 布局变化由工程同学修改脚本。

## HTML

输出为 UTF-8 自包含单文件，不引用 CDN。包含总览、问题表、根因汇总、J1—J4 摘要、Trace 节点和可展开证据。所有用户内容均 HTML 转义，避免脚本注入。

若输出名为 `.json`，脚本写出结构化 report model；否则写 HTML。
