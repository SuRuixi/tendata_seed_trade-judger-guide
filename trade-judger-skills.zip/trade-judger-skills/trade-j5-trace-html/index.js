#!/usr/bin/env node
'use strict';

const path = require('node:path');
const {
  escapeHtml: e, readJson, requireArray, requireObject, requireString, writeJson, writeText
} = require('../shared/lib');

const OWNERS = new Set(['model', 'source', 'tool', 'system_prompt', 'skill', 'mixed', 'unknown']);
const SEVERITIES = ['info', 'minor', 'major', 'critical'];
const TRI = new Set(['yes', 'no', 'unknown']);

function diagnose(input) {
  requireObject(input);
  requireString(input.task_id, 'task_id');
  requireString(input.model_id, 'model_id');
  const findings = requireArray(input.findings, 'findings');
  requireArray(input.trace_nodes, 'trace_nodes');
  const ids = new Set();
  const severityCounts = Object.fromEntries(SEVERITIES.map(key => [key, 0]));
  const rootMap = new Map();

  findings.forEach((finding, index) => {
    requireObject(finding, `findings[${index}]`);
    requireString(finding.id, `findings[${index}].id`);
    requireString(finding.title, `${finding.id}.title`);
    requireString(finding.root_cause, `${finding.id}.root_cause`);
    requireString(finding.remediation, `${finding.id}.remediation`);
    if (ids.has(finding.id)) throw new Error(`重复 finding id：${finding.id}`);
    if (!SEVERITIES.includes(finding.severity) || !OWNERS.has(finding.owner)) throw new Error(`非法 finding：${finding.id}`);
    requireArray(finding.judgement_refs, `${finding.id}.judgement_refs`);
    requireArray(finding.evidence_refs, `${finding.id}.evidence_refs`);
    if (!finding.judgement_refs.length) throw new Error(`${finding.id} 缺少 judgement_refs`);
    requireObject(finding.matrix, `${finding.id}.matrix`);
    for (const value of Object.values(finding.matrix)) {
      if (!TRI.has(value)) throw new Error(`${finding.id} 的证据矩阵值非法`);
    }
    ids.add(finding.id);
    severityCounts[finding.severity]++;
    const key = `${finding.owner}\u0000${finding.root_cause}`;
    const root = rootMap.get(key) || { owner: finding.owner, root_cause: finding.root_cause, finding_ids: [] };
    root.finding_ids.push(finding.id);
    rootMap.set(key, root);
  });

  return {
    ...input,
    conflicts: input.conflicts || [],
    generated_at: new Date().toISOString(),
    root_causes: [...rootMap.values()],
    severity_counts: severityCounts
  };
}

function badge(text, cls = '') {
  return `<span class="badge ${cls}">${e(text)}</span>`;
}

function renderHtml(report) {
  const findings = report.findings.map(f => `
    <article class="finding ${e(f.severity)}">
      <header><h3>${e(f.title)}</h3>${badge(f.severity, f.severity)}${badge(f.owner)}</header>
      <p>${e(f.root_cause)}</p>
      <dl><dt>证据</dt><dd>${f.evidence_refs.map(x => `<code>${e(x)}</code>`).join(' ') || '无'}</dd>
      <dt>引用</dt><dd>${e(f.quoted_evidence || '—')}</dd>
      <dt>修复</dt><dd>${e(f.remediation)}</dd></dl>
      <details><summary>证据矩阵与上游引用</summary>
        <pre>${e(JSON.stringify({ matrix: f.matrix, judgement_refs: f.judgement_refs }, null, 2))}</pre>
      </details>
    </article>`).join('');
  const trace = report.trace_nodes.map((node, i) => `
    <li><span class="node-index">${i + 1}</span><div><strong>${e(node.kind)}</strong> ${badge(node.status || 'unknown')}
    <code>${e(node.id)}</code><p>${e(node.summary)}</p></div></li>`).join('');
  const roots = report.root_causes.map(root =>
    `<tr><td>${e(root.owner)}</td><td>${e(root.root_cause)}</td><td>${root.finding_ids.map(e).join('、')}</td></tr>`
  ).join('');
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${e(report.model_id)} · ${e(report.task_id)} · Trace 诊断</title>
<style>
:root{--bg:#f5f7fb;--ink:#172033;--muted:#667085;--card:#fff;--line:#e4e7ec;--accent:#3659e3}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 system-ui,-apple-system,sans-serif}
main{max-width:1120px;margin:auto;padding:34px 22px}h1{font-size:30px;margin:0 0 4px}.sub{color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.metric,.panel,.finding{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}
.metric b{display:block;font-size:26px}.panel{margin:16px 0}.findings{display:grid;gap:12px}.finding{border-left:5px solid #98a2b3}.finding.critical{border-left-color:#d92d20}.finding.major{border-left-color:#f79009}
.finding header{display:flex;gap:8px;align-items:center}.finding h3{margin:0 auto 0 0}.badge{border-radius:999px;background:#eef2ff;padding:2px 8px;font-size:12px}.badge.critical{background:#fee4e2}.badge.major{background:#fef0c7}
dl{display:grid;grid-template-columns:60px 1fr;gap:8px}dt{font-weight:700}dd{margin:0}code,pre{background:#f2f4f7;border-radius:6px;padding:2px 5px}pre{padding:12px;overflow:auto}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px;border-bottom:1px solid var(--line)}
.trace{list-style:none;padding:0}.trace li{display:flex;gap:12px;border-left:2px solid #b9c5f8;margin-left:13px;padding:0 0 20px 20px}.node-index{margin-left:-34px;background:var(--accent);color:#fff;width:26px;height:26px;border-radius:50%;text-align:center;line-height:26px}.trace p{margin:4px 0;color:var(--muted)}
@media(max-width:720px){.grid{grid-template-columns:repeat(2,1fr)}dl{grid-template-columns:1fr}}
</style></head><body><main>
<h1>Trace 诊断报告</h1><div class="sub">${e(report.task_id)} · ${e(report.model_id)} · ${e(report.generated_at)}</div>
<section class="grid">${SEVERITIES.map(s => `<div class="metric"><span>${e(s)}</span><b>${report.severity_counts[s]}</b></div>`).join('')}</section>
<section class="panel"><h2>根因汇总</h2><table><thead><tr><th>责任方</th><th>根因</th><th>Finding</th></tr></thead><tbody>${roots}</tbody></table></section>
<section><h2>问题与证据</h2><div class="findings">${findings || '<p>未发现问题。</p>'}</div></section>
<section class="panel"><h2>J1—J4 摘要</h2><pre>${e(JSON.stringify({ judger_summary: report.judger_summary, ranking_summary: report.ranking_summary, conflicts: report.conflicts }, null, 2))}</pre></section>
<section class="panel"><h2>Trace 节点</h2><ol class="trace">${trace}</ol></section>
</main></body></html>`;
}

function main() {
  try {
    if (!process.argv[2]) throw new Error('用法：node index.js <input.json> [report.html|report.json]');
    const input = readJson(process.argv[2]);
    const report = diagnose(input);
    const output = path.resolve(process.argv[3] || 'trace-report.html');
    if (output.endsWith('.json')) writeJson(output, report);
    else writeText(output, renderHtml(report));
    process.stdout.write(`${output}\n`);
  } catch (error) {
    process.stderr.write(`${error.name || 'Error'}: ${error.message}\n`);
    process.exitCode = 1;
  }
}

if (require.main === module) main();
module.exports = { diagnose, renderHtml };
