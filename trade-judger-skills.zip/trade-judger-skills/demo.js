#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { evaluate: j1 } = require('./trade-j1-methodology');
const { evaluate: j2 } = require('./trade-j2-fidelity');
const { evaluate: j3 } = require('./trade-j3-completeness');
const { evaluate: j4 } = require('./trade-j4-pairwise-btd');
const { diagnose, renderHtml } = require('./trade-j5-trace-html');
const { readJson, writeJson, writeText } = require('./shared/lib');

const root = __dirname;
const output = path.join(root, 'demo-output');
fs.rmSync(output, { recursive: true, force: true });
fs.mkdirSync(output, { recursive: true });

const assertions = [];
function test(name, condition, detail) {
  assertions.push({ name, passed: Boolean(condition), detail });
  if (!condition) throw new Error(`断言失败：${name}；${detail}`);
}

function validateSchemas() {
  const skills = [
    'trade-j1-methodology', 'trade-j2-fidelity', 'trade-j3-completeness',
    'trade-j4-pairwise-btd', 'trade-j5-trace-html'
  ];
  for (const skill of skills) {
    const dir = path.join(root, skill);
    for (const file of ['SKILL.md', 'prompt.md', 'schema.json', 'index.js']) {
      test(`${skill}/${file} 存在`, fs.existsSync(path.join(dir, file)), '完整 Skill 文件检查');
    }
    const schema = readJson(path.join(dir, 'schema.json'));
    test(`${skill} Schema 版本`, schema.$schema.includes('2020-12'), schema.$schema);
    test(`${skill} Schema 含输入输出`, Boolean(schema.$defs?.input && schema.$defs?.output), '检查 $defs');
  }
}

function run() {
  validateSchemas();
  const a = readJson(path.join(root, 'shared/examples/model-a.json'));
  const b = readJson(path.join(root, 'shared/examples/model-b.json'));

  const results = {
    a: { j1: j1(a.j1), j2: j2(a.j2), j3: j3(a.j3) },
    b: { j1: j1(b.j1), j2: j2(b.j2), j3: j3(b.j3) }
  };
  writeJson(path.join(output, 'j1-model-a.json'), results.a.j1);
  writeJson(path.join(output, 'j2-model-a.json'), results.a.j2);
  writeJson(path.join(output, 'j3-model-a.json'), results.a.j3);
  writeJson(path.join(output, 'j1-model-b.json'), results.b.j1);
  writeJson(path.join(output, 'j2-model-b.json'), results.b.j2);
  writeJson(path.join(output, 'j3-model-b.json'), results.b.j3);

  test('J1 识别 critical failure', results.b.j1.critical_failure, `score=${results.b.j1.score}`);
  test('J1 A 分数高于 B', results.a.j1.score > results.b.j1.score, `${results.a.j1.score} > ${results.b.j1.score}`);
  test('J2 B 偏差率高于 A', results.b.j2.weighted_deviation_rate > results.a.j2.weighted_deviation_rate,
    `${results.b.j2.weighted_deviation_rate} > ${results.a.j2.weighted_deviation_rate}`);
  test('J3 A 完整度高于 B', results.a.j3.overall_score > results.b.j3.overall_score,
    `${results.a.j3.overall_score} > ${results.b.j3.overall_score}`);

  const pairwise = {
    models: ['model-a', 'model-b'],
    comparisons: [
      {
        task_id: 'trade-demo-001', a: 'model-a', b: 'model-b', outcome: 'A', confidence: 0.99,
        decisive_dimensions: ['critical_failure', 'sourcing_fidelity'],
        evidence_refs: ['j1:model-b:transformation', 'j2:model-b:b-c1', 'j2:model-b:b-c2'],
        reason: 'B 有核心币种和同比错误，A 无 critical failure'
      },
      {
        task_id: 'trade-demo-002', a: 'model-b', b: 'model-a', outcome: 'B', confidence: 0.95,
        decisive_dimensions: ['required_coverage'],
        evidence_refs: ['j3:model-a:r3', 'j3:model-b:r3'],
        reason: '交换位置后仍由 model-a 获胜'
      },
      {
        task_id: 'trade-demo-003', a: 'model-a', b: 'model-b', outcome: 'Same', confidence: 0.7,
        decisive_dimensions: [],
        evidence_refs: ['j3:model-a:r1', 'j3:model-b:r1'],
        reason: '该任务仅要求形式覆盖，双方均完成'
      }
    ],
    iterations: 1800,
    group_threshold: 8
  };
  writeJson(path.join(output, 'j4-pairs.json'), pairwise);
  const ranking = j4(pairwise);
  writeJson(path.join(output, 'ranking.json'), ranking);
  test('J4 使用 BTD', ranking.method === 'Bradley-Terry-Davidson MLE', ranking.method);
  test('J4 含平局参数', ranking.tie_parameter > 0, `nu=${ranking.tie_parameter}`);
  test('J4 排名 model-a 在前', ranking.rankings[0].model_id === 'model-a', ranking.rankings.map(x => x.model_id).join(','));

  const j5Input = {
    task_id: b.task_id,
    model_id: b.model_id,
    findings: [
      {
        id: 'f1',
        title: '币种与单位转换缺失',
        severity: 'critical',
        confidence: 0.98,
        owner: 'mixed',
        judgement_refs: ['j1:transformation', 'j2:b-c1'],
        evidence_refs: ['trace:b:source', 'trace:b:write', 'source:b:1', 'report:b:p1'],
        quoted_evidence: '来源为 1.2 亿元人民币，报告写为 1.2 亿美元',
        root_cause: '非原始来源未标准化币种，模型写作前也未执行单位检查',
        remediation: '优先拉取原始统计源；在写作前执行币种、单位与汇率断言',
        matrix: {
          correct_evidence_available: 'yes',
          conflicting_evidence_present: 'no',
          model_used_correct_evidence: 'no',
          report_presented_faithfully: 'no'
        }
      },
      {
        id: 'f2',
        title: '同比公式遗漏减一',
        severity: 'critical',
        confidence: 0.99,
        owner: 'model',
        judgement_refs: ['j1:calculation', 'j2:b-c2'],
        evidence_refs: ['artifact:b:calc', 'trace:b:write', 'report:b:p1'],
        quoted_evidence: '120/100=120%',
        root_cause: '模型把倍数直接当作增长率，且写作前没有复算',
        remediation: '统一使用 (本期/上期)-1，并增加结果范围检查',
        matrix: {
          correct_evidence_available: 'yes',
          conflicting_evidence_present: 'no',
          model_used_correct_evidence: 'yes',
          report_presented_faithfully: 'no'
        }
      }
    ],
    trace_nodes: b.trace_nodes,
    judger_summary: {
      j1: { score: results.b.j1.score, critical_failure: results.b.j1.critical_failure },
      j2: { weighted_deviation_rate: results.b.j2.weighted_deviation_rate, critical_failure: results.b.j2.critical_failure },
      j3: { required_coverage: results.b.j3.required_coverage, overall_score: results.b.j3.overall_score }
    },
    ranking_summary: ranking.rankings.find(row => row.model_id === 'model-b'),
    conflicts: []
  };
  const report = diagnose(j5Input);
  writeJson(path.join(output, 'j5.json'), report);
  const html = renderHtml(report);
  writeText(path.join(output, 'trace-report.html'), html);
  test('J5 合并根因', report.root_causes.length === 2, `root_causes=${report.root_causes.length}`);
  test('J5 HTML 自包含', html.includes('<!doctype html>') && !/https?:\/\//.test(html), `bytes=${Buffer.byteLength(html)}`);
  test('J5 HTML 内容转义', !html.includes('<script src='), '无外部脚本');

  const summary = {
    generated_at: new Date().toISOString(),
    node: process.version,
    assertions_total: assertions.length,
    assertions_passed: assertions.filter(item => item.passed).length,
    assertions_failed: assertions.filter(item => !item.passed).length,
    metrics: {
      model_a: {
        j1_score: results.a.j1.score,
        j2_deviation_rate: results.a.j2.weighted_deviation_rate,
        j3_score: results.a.j3.overall_score
      },
      model_b: {
        j1_score: results.b.j1.score,
        j2_deviation_rate: results.b.j2.weighted_deviation_rate,
        j3_score: results.b.j3.overall_score
      },
      ranking: ranking.rankings
    },
    assertions
  };
  writeJson(path.join(output, 'test-summary.json'), summary);
  process.stdout.write(`PASS ${summary.assertions_passed}/${summary.assertions_total}\n`);
  process.stdout.write(`${path.join(output, 'trace-report.html')}\n`);
}

try {
  run();
} catch (error) {
  writeJson(path.join(output, 'test-summary.json'), {
    generated_at: new Date().toISOString(),
    assertions_total: assertions.length,
    assertions_passed: assertions.filter(item => item.passed).length,
    assertions_failed: assertions.filter(item => !item.passed).length + 1,
    error: error.message,
    assertions
  });
  process.stderr.write(`${error.stack}\n`);
  process.exitCode = 1;
}
