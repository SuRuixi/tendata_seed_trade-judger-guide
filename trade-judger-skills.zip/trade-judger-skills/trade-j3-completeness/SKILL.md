---
name: "trade-j3-completeness"
description: "检查外贸分析报告是否完整满足任务和交付约束。用户要求拆任务契约、查必选项缺失或条件要求覆盖时触发。"
version: "1.0.0"
---

# J3 完整性 Judger

## 唯一职责

把用户任务拆为 requirement，并核验最终报告是否覆盖。不得重复评价方法正确性、数据真实性或模型排名。

## Requirement 类型

- `required`：明确要求；缺失直接影响完整性；
- `conditional`：条件触发后才必须满足，例如使用估算后披露方法；
- `optional`：有帮助但非必需，不能靠堆砌获得大量加分。

覆盖状态为 `covered`、`partial`、`missing`、`not_triggered` 或 `insufficient_evidence`。

## 工作流

1. 先读取 `expert-rules.md` 和 `expert-cases.jsonl`，应用专家确认的任务覆盖规则。
2. 从任务、系统约束和明确交付格式建立任务契约。
3. 为 conditional 项记录 `triggered`。
4. 在最终报告中定位覆盖证据；不要因 trace 中做过但未交付而判 covered。
5. 记录无关扩展，但不得把短报告自动判差。
6. 执行 `node index.js input.json output.json`。

## 专家如何修改

新增某类报告必须回答的内容或条件披露时，编辑 `expert-rules.md`，并在 `expert-cases.jsonl` 提供 covered、partial、missing 案例。若要改变 Requirement 权重，再由工程同学修改脚本。

## 聚合

`covered=1`、`partial=0.5`、`missing=0`。`required_coverage` 只计算 required；`conditional_coverage` 只计算已触发 conditional；`overall_score` 中 required 权重 3、已触发 conditional 权重 2、optional 权重 0.25。

## 证据纪律

partial/missing 必须给 evidence refs 或指出任务要求与报告缺口。证据不足不强制判 missing。
