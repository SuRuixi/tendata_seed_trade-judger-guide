#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const skillNames = [
  'trade-j1-methodology',
  'trade-j2-fidelity',
  'trade-j3-completeness',
  'trade-j4-pairwise-btd',
  'trade-j5-trace-html'
];

function copyDirectory(source, target) {
  fs.mkdirSync(target, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name);
    const to = path.join(target, entry.name);
    if (entry.isDirectory()) copyDirectory(from, to);
    else fs.copyFileSync(from, to);
  }
}

function main() {
  const destination = path.resolve(process.argv[2] || path.join(process.cwd(), '.trae', 'skills'));
  for (const skillName of skillNames) {
    const source = path.join(__dirname, skillName);
    const target = path.join(destination, skillName);
    copyDirectory(source, target);
    process.stdout.write(`installed ${skillName} -> ${target}\n`);
  }
}

try {
  main();
} catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
