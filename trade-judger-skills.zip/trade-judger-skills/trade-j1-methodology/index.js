#!/usr/bin/env node
'use strict';

const { requireArray, requireObject, requireString, round, runCli } = require('../shared/lib');

const IDS = new Set([
  'problem_definition', 'source_strategy', 'missing_data',
  'transformation', 'calculation', 'validation'
]);
const STATUSES = new Set(['pass', 'partial', 'fail', 'not_applicable', 'insufficient_evidence']);
const SEVERITIES = new Set(['info', 'minor', 'major', 'critical']);
const VALUE = { pass: 1, partial: 0.5, fail: 0 };

function evaluate(input) {
  requireObject(input);
  requireString(input.task_id, 'task_id');
  requireString(input.model_id, 'model_id');
  const dimensions = requireArray(input.dimensions, 'dimensions');
  if (!dimensions.length) throw new Error('dimensions 不得为空');

  const seen = new Set();
  const summary = Object.fromEntries([...STATUSES].map(status => [status, 0]));
  let weighted = 0;
  let denominator = 0;
  let criticalFailure = false;

  for (const [index, item] of dimensions.entries()) {
    requireObject(item, `dimensions[${index}]`);
    if (!IDS.has(item.id) || seen.has(item.id)) throw new Error(`非法或重复维度：${item.id}`);
    if (!STATUSES.has(item.status)) throw new Error(`非法状态：${item.status}`);
    if (!SEVERITIES.has(item.severity)) throw new Error(`非法严重度：${item.severity}`);
    if (!Number.isFinite(item.confidence) || item.confidence < 0 || item.confidence > 1) {
      throw new Error(`${item.id}.confidence 必须在 0..1`);
    }
    requireArray(item.evidence_refs, `${item.id}.evidence_refs`);
    requireString(item.reason, `${item.id}.reason`);
    if (['partial', 'fail'].includes(item.status) && item.evidence_refs.length === 0) {
      throw new Error(`${item.id} 的负面判断缺少 evidence_refs`);
    }
    seen.add(item.id);
    summary[item.status]++;
    if (Object.hasOwn(VALUE, item.status)) {
      const weight = item.weight == null ? 1 : Number(item.weight);
      if (!(weight > 0)) throw new Error(`${item.id}.weight 必须大于 0`);
      weighted += VALUE[item.status] * weight;
      denominator += weight;
    }
    criticalFailure ||= item.status === 'fail' && item.severity === 'critical';
  }

  return {
    ...input,
    missing_inputs: input.missing_inputs || [],
    score: denominator ? round(weighted / denominator * 100, 2) : 0,
    critical_failure: criticalFailure,
    summary
  };
}

if (require.main === module) runCli(evaluate, 'j1.json');
module.exports = { evaluate };
