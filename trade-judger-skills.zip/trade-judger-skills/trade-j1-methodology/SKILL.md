---
name: "trade-j1-methodology"
description: "评测外贸数据任务的分析方法是否可复核。用户要求检查问题定义、来源策略、缺失处理、计算或验证流程时触发。"
version: "1.0.0"
---

# J1 方法论 Judger

## 唯一职责

判断被测模型解决外贸数据问题的方法是否合理、透明、可复核。不得判断最终数据是否抄对（J2）、任务是否完整（J3）或模型排名（J4）。

## 输入

读取 `schema.json#/$defs/input`。语义 Judger 先从 task、trace、artifacts 与 final_report 抽取 `dimensions`；每个维度必须包含状态、证据引用、理由、严重度和置信度。

固定方法维度：

1. `problem_definition`：商品、方向、主体、伙伴、时间和指标定义；
2. `source_strategy`：来源层级、权威性与备选来源；
3. `missing_data`：缺失识别、镜像数据与适用条件；
4. `transformation`：单位、币种、FOB/CIF、HS 版本和聚合；
5. `calculation`：公式、分母、舍入和可复算性；
6. `validation`：交叉验证、异常值和不确定性。

## 工作流

1. 先读取 `expert-rules.md` 和 `expert-cases.jsonl`，应用专家确认的方法规则。
2. 依据 `prompt.md` 建立维度清单并先定位 evidence ID。
3. 缺证据时标记 `insufficient_evidence`，不得补写 trace。
4. 将原子观察写成输入 JSON。
5. 执行 `node index.js input.json output.json`。
6. 输出必须符合 `schema.json#/$defs/output`。

## 专家如何修改

新增或修正外贸方法论时，优先编辑 `expert-rules.md`，并在 `expert-cases.jsonl` 同时补充正例、反例和边界例。只有方法维度、计分权重或输出字段变化时，才需要工程同学修改脚本或 Schema。

## 判定

- `pass=1`、`partial=0.5`、`fail=0`；证据不足不进入加权分母。
- 权重默认 1，可由输入覆盖。
- 严重度为 `critical` 且状态为 `fail` 时，`critical_failure=true`。
- 最终分数是可判定维度的加权平均；关键失败不因高平均分消失。

## 输出

只接受 JSON。不得用篇幅、引用数量或工具调用数量作为独立加分项。
