# Trade Judger Skills

面向外贸数据分析评测的五个独立 Skill，所有可执行代码仅使用 Node.js 内置模块。

## 外贸数据专家从这里开始

先阅读 `EXPERT_CONTRIBUTION_GUIDE.md`。每个 Skill 新增了两个专家入口：

- `expert-rules.md`：维护外贸方法、偏差、完整性、比较或归因规则；
- `expert-cases.jsonl`：维护正例、反例和边界例。

专家通常不需要修改 `schema.json` 或 `index.js`。当规则与案例已经明确，但输出字段、计分权重或聚合公式仍需变化时，再交给工程同学处理。

## 目录

| Skill | 职责 | 主要产物 |
|---|---|---|
| `trade-j1-methodology` | J1 方法论评测 | 方法维度、关键失败、总分 |
| `trade-j2-fidelity` | J2 数据忠实度 | Claim 溯源、偏差率、关键失败 |
| `trade-j3-completeness` | J3 完整性 | 任务契约、必选覆盖率 |
| `trade-j4-pairwise-btd` | J4 Pairwise + BTD 排序 | Pairwise 判定、强度、分数、rank group |
| `trade-j5-trace-html` | J5 Trace 诊断 | 根因、证据矩阵、自包含 HTML |

每个 Skill 均含：

- `SKILL.md`：触发条件、职责边界和执行流程；
- `prompt.md`：可直接交给 Judger 模型的中文提示词；
- `expert-rules.md`：专家可直接维护的业务判断规则；
- `expert-cases.jsonl`：用于校准规则边界的案例；
- `schema.json`：Draft 2020-12 输入/输出 JSON Schema；
- `index.js`：命令行执行器，支持 `node index.js <input.json> [output]`。

共享目录：

- `shared/examples/`：可复现的演示输入；
- `shared/lib.js`：参数、读写、基础校验和 HTML 转义；
- `demo.js`：串联 J1—J5 的一键演示。
- `install.js`：把五个 Skill 复制到指定的 `.trae/skills/` 目录。

## 环境

- Node.js 18 或更高版本；
- 无 npm 依赖，无需安装；
- 不访问网络。

## 一键验证

```bash
node demo.js
```

演示会在 `demo-output/` 写出：

- `j1.json`、`j2.json`、`j3.json`；
- `j4-pairs.json`、`ranking.json`；
- `j5.json`、`trace-report.html`；
- `test-summary.json`。

重复运行会覆盖这些演示产物。返回码为 `0` 表示全部断言通过。

## 安装到项目

在目标项目根目录执行：

```bash
node /path/to/trade-judger-skills/install.js
```

默认安装到当前目录的 `.trae/skills/`。也可以显式指定目标目录：

```bash
node install.js /path/to/project/.trae/skills
```

## 单独运行

```bash
node trade-j1-methodology/index.js shared/examples/j1.json j1.json
node trade-j2-fidelity/index.js shared/examples/j2.json j2.json
node trade-j3-completeness/index.js shared/examples/j3.json j3.json
node trade-j4-pairwise-btd/index.js shared/examples/j4.json ranking.json
node trade-j5-trace-html/index.js shared/examples/j5.json trace-report.html
```

J1—J3 的 Node 执行器消费“已抽取的原子观察”，负责规则化评分与 Schema 形状校验；语义抽取由各自 `prompt.md` 约束。J4 实现 Davidson 平局扩展的迭代极大似然估计；J5 生成不依赖 CDN 的单文件 HTML。

## 证据纪律

1. 先定位证据，再下结论；负面判断必须带 `evidence_refs`。
2. 缺少证据时使用 `insufficient_evidence`，不得用常识补写。
3. Critical failure 不得被平均分抵消。
4. 篇幅、引用数和工具调用数本身不构成质量优势。
5. J5 只融合和归因，不修改 J1—J4 的原始结论。
