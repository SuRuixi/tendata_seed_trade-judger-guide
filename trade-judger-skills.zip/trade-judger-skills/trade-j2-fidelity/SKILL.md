---
name: "trade-j2-fidelity"
description: "核验外贸报告中的数值与定量结论是否忠实于来源和变换过程。用户要求查数据偏差、溯源链或核心数据错误时触发。"
version: "1.0.0"
---

# J2 数据忠实度 Judger

## 唯一职责

逐个核验最终报告中的 data claim，建立 `claim → transformation → source` 链。不得因方法看起来专业而忽略数据错误，也不得评价任务覆盖或模型排名。

## 偏差分类

- `none`：来源、定义、时间、单位和计算一致；
- `transcription`：抄写错误；
- `definition`：贸易方向、主体、伙伴、商品口径不一致；
- `time`：年份、月份、累计窗口或披露时点不一致；
- `unit_currency`：数量单位、币种、名义/实际值错误；
- `aggregation`：重复、漏项或错误汇总；
- `calculation`：公式、分母、增长率或舍入错误；
- `source_quality`：来源不可定位或不足以支撑 claim；
- `insufficient_evidence`：输入不足，无法核验。

## 工作流

1. 先读取 `expert-rules.md` 和 `expert-cases.jsonl`，应用专家确认的偏差规则。
2. 用 `prompt.md` 从报告抽取所有承重 data claim。
3. 为每项记录报告值、变换说明、来源值、来源引用和证据。
4. 区分模型原始来源与 Judger 外部复核证据。
5. 执行 `node index.js input.json output.json`。
6. 输出符合 `schema.json#/$defs/output`。

## 专家如何修改

新增统计口径、数据偏差或严重度判断时，优先编辑 `expert-rules.md`，并在 `expert-cases.jsonl` 增加成对案例。若要改变严重度权重或偏差率公式，再由工程同学修改 `index.js`。

## 聚合

严重度权重为 `info=0`、`minor=1`、`major=3`、`critical=8`。加权偏差率等于偏差 claim 权重除以全部可核验 claim 权重；critical 偏差同时设置 `critical_failure=true`。

## 证据纪律

定义错误即使数值接近也不能判正确。无法定位来源时不得以常识补全。每个非 `none` 且非证据不足的判断必须含 evidence refs。
