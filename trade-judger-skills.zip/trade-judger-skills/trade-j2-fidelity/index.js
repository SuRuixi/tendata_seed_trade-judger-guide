#!/usr/bin/env node
'use strict';

const { requireArray, requireObject, requireString, round, runCli } = require('../shared/lib');

const DEVIATIONS = [
  'none', 'transcription', 'definition', 'time', 'unit_currency',
  'aggregation', 'calculation', 'source_quality', 'insufficient_evidence'
];
const SEVERITIES = new Set(['info', 'minor', 'major', 'critical']);
const SEVERITY_WEIGHT = { info: 0, minor: 1, major: 3, critical: 8 };

function evaluate(input) {
  requireObject(input);
  requireString(input.task_id, 'task_id');
  requireString(input.model_id, 'model_id');
  const claims = requireArray(input.claims, 'claims');
  if (!claims.length) throw new Error('claims 不得为空');

  const ids = new Set();
  const counts = Object.fromEntries(DEVIATIONS.map(key => [key, 0]));
  let deviationWeight = 0;
  let totalWeight = 0;
  let criticalFailure = false;

  claims.forEach((claim, index) => {
    requireObject(claim, `claims[${index}]`);
    requireString(claim.id, `claims[${index}].id`);
    requireString(claim.text, `${claim.id}.text`);
    requireString(claim.transformation, `${claim.id}.transformation`);
    requireString(claim.reason, `${claim.id}.reason`);
    if (ids.has(claim.id)) throw new Error(`重复 claim id：${claim.id}`);
    if (!DEVIATIONS.includes(claim.deviation)) throw new Error(`非法偏差：${claim.deviation}`);
    if (!SEVERITIES.has(claim.severity)) throw new Error(`非法严重度：${claim.severity}`);
    requireArray(claim.source_refs, `${claim.id}.source_refs`);
    requireArray(claim.evidence_refs, `${claim.id}.evidence_refs`);
    if (!['none', 'insufficient_evidence'].includes(claim.deviation) && !claim.evidence_refs.length) {
      throw new Error(`${claim.id} 的偏差判断缺少 evidence_refs`);
    }
    ids.add(claim.id);
    counts[claim.deviation]++;
    if (claim.deviation !== 'insufficient_evidence') {
      const importance = claim.importance == null ? 1 : Number(claim.importance);
      if (!(importance > 0)) throw new Error(`${claim.id}.importance 必须大于 0`);
      const base = Math.max(1, SEVERITY_WEIGHT[claim.severity]);
      totalWeight += importance * base;
      if (claim.deviation !== 'none') deviationWeight += importance * base;
    }
    criticalFailure ||= claim.deviation !== 'none' &&
      claim.deviation !== 'insufficient_evidence' && claim.severity === 'critical';
  });

  return {
    ...input,
    missing_inputs: input.missing_inputs || [],
    weighted_deviation_rate: totalWeight ? round(deviationWeight / totalWeight) : 0,
    critical_failure: criticalFailure,
    counts
  };
}

if (require.main === module) runCli(evaluate, 'j2.json');
module.exports = { evaluate };
